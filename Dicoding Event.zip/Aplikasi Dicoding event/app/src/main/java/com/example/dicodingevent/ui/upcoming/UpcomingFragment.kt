package com.example.dicodingevent.ui.upcoming

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.bumptech.glide.Glide
import com.example.Dicoding_event.R
import com.example.Dicoding_event.databinding.FragmentUpcomingBinding
import com.example.dicodingevent.ui.EventViewModel
import com.example.dicodingevent.ui.ViewModelFactory
import com.example.dicodingevent.data.Result
import com.example.dicodingevent.data.local.entity.EventEntity
import com.example.dicodingevent.datastore.DataStoreViewModel
import com.example.dicodingevent.datastore.SettingPrefernces
import com.example.dicodingevent.datastore.dataStore
import com.example.dicodingevent.ui.detail.DetailUserActivity.Companion.EXTRA_ACTIVITY
import com.example.dicodingevent.ui.detail.DetailUserActivity.Companion.EXTRA_ID

class UpcomingFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentUpcomingBinding? = null
    private val binding get() = _binding!!

    var id: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUpcomingBinding.inflate(inflater, container, false)
      return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory: ViewModelFactory = ViewModelFactory.getInstance(requireActivity())
        val viewModel: EventViewModel by viewModels { factory }

        getUpComing(viewModel)
        getSavedTheme()

        binding.cvUpcoming.setOnClickListener(this)
    }

    private fun getSavedTheme(){
        val pref = SettingPrefernces.getInstance(requireActivity().dataStore)
        val dataStoreViewModel = ViewModelProvider(requireActivity(),
            com.example.dicodingevent.datastore.ViewModelFactory(pref)
        ).get(
            DataStoreViewModel::class.java
        )
        dataStoreViewModel.getThemeSettings().observe(requireActivity()) { isDarkModeActive ->
            if (isDarkModeActive) AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    private fun getUpComing(viewModel: EventViewModel) {
        viewModel.getUpComing().observe(viewLifecycleOwner) { result ->
            if (result !=null) {
                when (result) {
                    is Result.Loading -> binding.progressBar.visibility = View.VISIBLE
                    is Result.Success -> {
                        binding.progressBar.visibility = View.GONE
                        val eventData = result.data
                        eventData.forEach {
                            getOutputUpcoming(it)
                            Log.e(TAG, it.name as String)
                        }
                    }

                    is Result.Error -> {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(context, "Terjadi kesalahan" + result.error, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun getOutputUpcoming(item: EventEntity) {
        Glide.with(this@UpcomingFragment)
            .load(item.mediaCover)
            .into(binding.ivUpcoming)
        binding.tvTitleUpcoming.text = item.name
        id = item.id
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.cv_upcoming -> {
                val bundle = Bundle()
                bundle.putString(EXTRA_ACTIVITY, UPCOMING_FRAGMENT)
                bundle.putString(EXTRA_ID, id)
                v.findNavController().navigate(R.id.action_navigation_upcoming_to_detailUserActivity, bundle)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val TAG = "UpComingFragment TEST REST API"
        const val UPCOMING_FRAGMENT = "UpcomingFragment"
    }
}