package com.example.dicodingevent.ui.detail

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.Dicoding_event.R
import com.example.Dicoding_event.databinding.ActivityDetailUserBinding
import com.example.dicodingevent.adapter.EventAdapter.Companion.EVENT_ADAPTER
import com.example.dicodingevent.data.Result
import com.example.dicodingevent.data.local.entity.EventEntity
import com.example.dicodingevent.data.remote.response.Detail
import com.example.dicodingevent.ui.EventViewModel
import com.example.dicodingevent.ui.ViewModelFactory
import com.example.dicodingevent.ui.upcoming.UpcomingFragment.Companion.UPCOMING_FRAGMENT

class DetailUserActivity : AppCompatActivity() {

    private var _binding: ActivityDetailUserBinding? = null
    private val binding get() = _binding!!
    var isFavorite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        val viewModel: EventViewModel by viewModels { factory }

        val id = intent.getStringExtra(EXTRA_ID).toString()
        val activity = intent.getStringExtra(EXTRA_ACTIVITY)

        if (activity == EVENT_ADAPTER) {
            Log.e(TAG_FINISHED, id)
            getFinished(viewModel, id)
            getIsFavorite(viewModel, id)
            viewModel.isEventFavorite(id).observe(this) { isFavorite ->
                setFiledFavorite(isFavorite)
            }

        } else if (activity == UPCOMING_FRAGMENT) {
            Log.e(TAG_UPCOMING, id)
            getUpComing(viewModel)
            getIsFavorite(viewModel, id)
            viewModel.isEventFavorite(id).observe(this) { isFavorite ->
                setFiledFavorite(isFavorite)
            }
        }
    }

    private fun getUpComing(viewModel: EventViewModel) {
        viewModel.getUpComing().observe(this) { result ->
            if (result !=null) {
                when (result) {
                    is Result.Loading -> binding.progressBar.visibility = View.VISIBLE
                    is Result.Success -> {
                        binding.progressBar.visibility = View.GONE
                        val eventData = result.data
                        eventData.forEach {
                            getOutputUpcoming(it)
                        }
                    }
                    is Result.Error -> {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this, "Terjadi kesalhan" + result.error, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun getFinished(viewModel: EventViewModel, id: String) {
        viewModel.getFinished().observe(this) { result ->
            if (result !=null) {
                when (result) {
                    is Result.Loading -> binding.progressBar.visibility = View.VISIBLE
                    is Result.Success -> {
                        binding.progressBar.visibility = View.GONE
                        viewModel.getDetail(id)
                        viewModel.detail.observe(this) {
                            getOutputFinished(it)
                        }
                    }
                    is Result.Error -> {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this, "Terjadi kesalahan" + result.error, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun getIsFavorite(viewModel: EventViewModel, id: String) {
        binding.fabDetail.setOnClickListener {
            isFavorite = !isFavorite
            viewModel.updateFavoriteEvent(id, isFavorite)
        }
    }

    private fun setFiledFavorite(isFavorite: Boolean) {
        if (isFavorite) {
            binding.fabDetail.setImageDrawable(ContextCompat.getDrawable(applicationContext, R.drawable.baseline_favorite_filled))
        } else {
            binding.fabDetail.setImageDrawable(ContextCompat.getDrawable(applicationContext, R.drawable.baseline_favorite))
        }
    }

    private fun getOutputUpcoming(item: EventEntity) {
        Glide.with(this@DetailUserActivity)
            .load(item.mediaCover)
            .into(binding.ivDetail)
        binding.tvTitleDetail.text = item.name
        binding.tvSummaryDetail.text = item.summary
        binding.tvDescription.text = item.description
    }

    private fun getOutputFinished(item: Detail) {
        Glide.with(this@DetailUserActivity)
            .load(item.mediaCover)
            .into(binding.ivDetail)
        binding.tvTitleDetail.text = item.name
        binding.tvSummaryDetail.text = item.summary
        binding.tvDescription.text = item.description
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    companion object {
        private const val TAG_UPCOMING = "DetailActivity UPCOMING TEST KLIK"
        private const val TAG_FINISHED = "DetailActivity FINISHED TEST KLIK"

        const val EXTRA_ID = "extra_id"
        const val EXTRA_ACTIVITY = "extra_activity"
    }
}