package com.example.dicodingevent.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.dicodingevent.data.EventRepository
import com.example.dicodingevent.data.remote.response.Detail
import com.example.dicodingevent.data.remote.response.DetailResponse
import com.example.dicodingevent.data.remote.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EventViewModel(private val eventRepository: EventRepository) : ViewModel() {

    private val _detail = MutableLiveData<Detail>()
    val detail: LiveData<Detail> = _detail

    fun getDetail(id: String) {
        val client = ApiConfig.getApiService().getDetail(id)
        client.enqueue(object : Callback<DetailResponse> {
            override fun onResponse(call: Call<DetailResponse>, response: Response<DetailResponse>) {
                if (response.isSuccessful) {
                    val detailItem = response.body()?.detail
                    _detail.value = response.body()?.detail
                    Log.e(TAG, detailItem.toString())
                }
            }

            override fun onFailure(call: Call<DetailResponse>, t: Throwable) {
                Log.e(TAG, t.toString())
            }
        })
    }

    fun getUpComing() = eventRepository.getUpComing()

    fun getFinished() = eventRepository.getFinished()

    fun getFavorite() = eventRepository.getFavorite()

    fun updateFavoriteEvent(id: String, favoriteState: Boolean) = eventRepository.updateFavoriteEvent(id, favoriteState)

    fun isEventFavorite(id: String) = eventRepository.isEventFavorite(id)

    companion object {
        const val TAG = "EventViewModel Test Data"
    }
}