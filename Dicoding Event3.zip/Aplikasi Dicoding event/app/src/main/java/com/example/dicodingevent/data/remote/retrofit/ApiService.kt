package com.example.dicodingevent.data.remote.retrofit

import com.example.dicodingevent.data.remote.response.DetailResponse
import com.example.dicodingevent.data.remote.response.FinishedResponse
import com.example.dicodingevent.data.remote.response.NewNotificationResponse
import com.example.dicodingevent.data.remote.response.UpcomingResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("events")
    fun getUpcoming(
        @Query("active") active: String = "1"
    ): Call<UpcomingResponse>

    @GET("events")
    fun getFinished(
        @Query("active") active: String = "0"
    ): Call<FinishedResponse>

    @GET("events/{id}")
    fun getDetail(
        @Path("id") id: String
    ): Call<DetailResponse>

    @GET("events")
    fun getNewNotification(
        @Query("active") active: String ="-1",
        @Query("limit") limit: String ="1"
    ): Call<NewNotificationResponse>
}