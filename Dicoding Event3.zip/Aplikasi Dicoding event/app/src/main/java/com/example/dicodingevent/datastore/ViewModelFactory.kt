package com.example.dicodingevent.datastore

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import java.lang.IllegalArgumentException

@Suppress("UNCHECKED_CAST")
class ViewModelFactory(private val pref: SettingPrefernces) : ViewModelProvider.NewInstanceFactory() {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DataStoreViewModel::class.java)){
            return DataStoreViewModel(pref) as T
        }
        throw IllegalArgumentException("unknown ViewModel class: " + modelClass.name)
    }
}